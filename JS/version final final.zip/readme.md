Jarnac Game
This repository contains the implementation of the Jarnac game. The game is implemented in JavaScript and can be run in a Node.js environment.

Files
Here is a brief description of each JavaScript file in the repository:

game.js: This file contains the main game logic, including the game loop and the functions to start and set up the game.

move.js: This file contains the logic for making moves in the game, including playing a word, passing a turn, and performing a "jarnac".

player.js: This file defines the Player class, which represents a player in the game. Each player has a name, a set of letters, and a set of words they have played.

letter.js: This file contains the logic for drawing letters and managing the letter pool.

word.js: This file contains the logic for managing words, including checking if a word is valid and adding a word to a player's set of words.

How to Play
Install Node.js on your machine if you haven't already.

Clone this repository to your local machine.

Navigate to the repository folder in your terminal.

Run node game.js to start the game.

Follow the prompts in the terminal to play the game. Each player will be asked to either play a word, pass their turn, or quit the game. The game continues until a player has played 8 words.

Please note that this game is a console-based game and does not have a graphical user interface. All interaction with the game is done through the terminal.